package com.yamini.assistant;

import android.app.*;import android.content.*;import android.os.*;import android.speech.*;import java.util.*;

public class WakeService extends Service{
 SpeechRecognizer sr; boolean listening=false;
 @Override public void onCreate(){super.onCreate(); createChannel(); Notification n=new Notification.Builder(this,"yamini").setContentTitle("Yamini").setContentText("Hey Yamini listening").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build(); startForeground(8,n); listen();}
 void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("yamini","Yamini",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
 void listen(){if(!SpeechRecognizer.isRecognitionAvailable(this))return; try{if(sr!=null)sr.destroy();sr=SpeechRecognizer.createSpeechRecognizer(this); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");sr.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle b){}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}public void onError(int e){new Handler().postDelayed(()->listen(),1200);}public void onResults(Bundle b){ArrayList<String>x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(x!=null&&!x.isEmpty()){String s=x.get(0).toLowerCase(Locale.ROOT);if(s.contains("hey yamini")||s.contains("हे यामिनी")){Intent a=new Intent(WakeService.this,MainActivity.class);a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);a.putExtra("wake_query",x.get(0));startActivity(a);} }new Handler().postDelayed(()->listen(),500);}public void onPartialResults(Bundle b){}public void onEvent(int a,Bundle b){}});sr.startListening(i);}catch(Exception e){new Handler().postDelayed(()->listen(),2000);}}
 @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
 @Override public void onDestroy(){if(sr!=null)sr.destroy();super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
