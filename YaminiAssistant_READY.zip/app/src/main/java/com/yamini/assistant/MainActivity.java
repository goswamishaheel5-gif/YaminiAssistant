package com.yamini.assistant;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int REQ=44;
    EditText input, apiKey;
    TextView chat,status;
    Button talk, bg;
    TextToSpeech tts;
    ExecutorService pool=Executors.newSingleThreadExecutor();
    android.content.SharedPreferences sp;

    @Override public void onCreate(Bundle b){ super.onCreate(b); sp=getSharedPreferences("yamini",0); build(); setupTts();
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ); Intent w=getIntent(); if(w!=null && w.hasExtra("wake_query")){ String q=w.getStringExtra("wake_query"); q=q.replaceAll("(?i)hey yamini|हे यामिनी"," ").trim(); if(!q.isEmpty()) ask(q); else { status.setText("Haan Sahil, main sun rahi hoon…"); listenOnce(); }}
    }
    TextView tv(String s,int size){ TextView v=new TextView(this); v.setText(s); v.setTextColor(Color.WHITE); v.setTextSize(size); v.setPadding(20,16,20,16); return v; }
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,30,18,18); root.setBackgroundColor(Color.rgb(15,15,20));
        TextView title=tv("Yamini  ♥",28); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        status=tv("Sahil, Yamini ready hai.",14); status.setTextColor(Color.LTGRAY); root.addView(status);
        ScrollView sv=new ScrollView(this); chat=tv("Yamini: Haan Sahil, bolo… main sun rahi hoon.\n\n",17); sv.addView(chat); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        input=new EditText(this); input.setHint("Type karo ya Talk dabao…"); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY); root.addView(input,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout row=new LinearLayout(this); talk=new Button(this); talk.setText("🎙 TALK"); bg=new Button(this); bg.setText("▶ Hey Yamini"); row.addView(talk,new LinearLayout.LayoutParams(0,-2,1)); row.addView(bg,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);
        apiKey=new EditText(this); apiKey.setHint("OpenAI API key (optional until AI is connected)"); apiKey.setInputType(129); apiKey.setText(sp.getString("key","")); root.addView(apiKey,new LinearLayout.LayoutParams(-1,-2));
        Button save=new Button(this); save.setText("Save AI Key"); root.addView(save);
        setContentView(root);
        talk.setOnClickListener(v->listenOnce());
        input.setOnEditorActionListener((v,a,e)->{ if(input.getText().length()>0){ask(input.getText().toString()); return true;} return false;});
        save.setOnClickListener(v->{sp.edit().putString("key",apiKey.getText().toString().trim()).apply(); status.setText("AI key saved on this phone.");});
        bg.setOnClickListener(v->toggleWake());
    }
    void setupTts(){ tts=new TextToSpeech(this,r->{ if(r==TextToSpeech.SUCCESS){ Locale hi=new Locale("hi","IN"); tts.setLanguage(hi); for(Voice v:tts.getVoices()) if(v.getLocale().getLanguage().equals("hi") && (v.getName().toLowerCase().contains("female")||v.getName().toLowerCase().contains("woman"))){tts.setVoice(v);break;} tts.setSpeechRate(.95f);} }); }
    void speak(String s){ if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"yamini"); }
    void listenOnce(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ);return;}
        SpeechRecognizer sr=SpeechRecognizer.createSpeechRecognizer(this); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
        status.setText("Sun rahi hoon, Sahil…"); sr.setRecognitionListener(new RecognitionListener(){ public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){} public void onError(int e){status.setText("Dobara TALK dabao, Sahil.");sr.destroy();} public void onResults(Bundle b){ArrayList<String>x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(x!=null&&!x.isEmpty())ask(x.get(0));sr.destroy();} public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){} }); sr.startListening(i);
    }
    void ask(String q){
        q=q.trim(); if(q.isEmpty())return; append("Sahil: "+q); input.setText(""); status.setText("Yamini soch rahi hai…");
        String key=sp.getString("key",""); if(key.isEmpty()){ String r=localReply(q); append("Yamini: "+r); speak(r); status.setText("Ready, Sahil."); return; }
        final String query=q; pool.execute(()->{try{String r=callAI(key,query); runOnUiThread(()->{append("Yamini: "+r); speak(r); status.setText("Ready, Sahil.");});}catch(Exception e){runOnUiThread(()->{String r="Sahil, AI connection me problem aa gayi. Internet/API key check karo.";append("Yamini: "+r);speak(r);status.setText("AI error");});}});
    }
    String localReply(String q){String l=q.toLowerCase(Locale.ROOT); if(l.contains("kaise ho")||l.contains("how are"))return "Main bilkul ready hoon, Sahil. Tum batao, aaj kya karna hai?"; if(l.contains("naam"))return "Mera naam Yamini hai, aur main tumhe Sahil bulaungi."; return "Sahil, main abhi basic mode me hoon. OpenAI API key add karoge to main kaafi zyada smart ho jaungi.";}
    String callAI(String key,String q)throws Exception{
        URL u=new URL("https://api.openai.com/v1/responses"); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setRequestProperty("Authorization","Bearer "+key); c.setRequestProperty("Content-Type","application/json"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(60000);
        JSONObject body=new JSONObject(); body.put("model","gpt-5.6-luna"); body.put("instructions","Your name is Yamini. You are Sahil's personal AI assistant. Always call him Sahil. Speak naturally in Hindi/Hinglish unless he asks another language. Be warm, caring, emotionally aware, smart and practical. Do not claim to have real human feelings. Keep voice answers concise unless Sahil asks for detail."); body.put("input",q);
        OutputStream os=c.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close(); int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); BufferedReader br=new BufferedReader(new InputStreamReader(is)); StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null)sb.append(line); br.close(); if(code<200||code>=300)throw new IOException("HTTP "+code+" "+sb);
        JSONObject out=new JSONObject(sb.toString()); if(out.has("output_text"))return out.getString("output_text");
        JSONArray arr=out.optJSONArray("output"); if(arr!=null)for(int i=0;i<arr.length();i++){JSONObject item=arr.optJSONObject(i); JSONArray content=item==null?null:item.optJSONArray("content"); if(content!=null)for(int j=0;j<content.length();j++){JSONObject cc=content.optJSONObject(j); if(cc!=null&&cc.has("text"))return cc.getString("text");}}
        return "Sahil, mujhe response nahi mila.";
    }
    void append(String s){chat.append(s+"\n\n");}
    void toggleWake(){ if(!sp.getBoolean("wake",false)){ if(Build.VERSION.SDK_INT>=26)startForegroundService(new Intent(this,WakeService.class)); else startService(new Intent(this,WakeService.class)); sp.edit().putBoolean("wake",true).apply(); bg.setText("■ Stop Hey Yamini"); status.setText("Background listening ON — Sahil, ‘Hey Yamini’ bolo."); } else {stopService(new Intent(this,WakeService.class));sp.edit().putBoolean("wake",false).apply();bg.setText("▶ Hey Yamini");status.setText("Background listening OFF");}}
    @Override protected void onDestroy(){super.onDestroy(); if(tts!=null)tts.shutdown();pool.shutdownNow();}
}
