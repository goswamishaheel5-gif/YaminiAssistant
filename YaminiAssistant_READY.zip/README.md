# Yamini — Sahil's Personal Voice AI (Android prototype)

This is a complete Android Studio project for a personal assistant named **Yamini**. She addresses the owner as **Sahil**, supports Hindi/Hinglish voice input, Android Text-to-Speech, local basic memory/settings, and optional OpenAI Responses API intelligence.

## What works
- Tap TALK → speak → Yamini answers by voice.
- Female Hindi voice is selected when the installed Android TTS engine exposes one; otherwise Android's default Hindi voice is used.
- Optional OpenAI API key stored locally in SharedPreferences.
- “Hey Yamini” foreground microphone service prototype.
- Yamini personality prompt always calls the owner Sahil.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android 8+ phone.
4. Allow microphone permission.
5. For smart AI, paste an OpenAI API key into the app and tap Save AI Key.

## Important limitation
Android background microphone/wake-word behavior is restricted by OS battery/privacy rules and varies by phone manufacturer. This project uses a foreground microphone service as a prototype; a production-grade always-on custom wake word should use a dedicated on-device wake-word engine and a secure backend for the AI API key.

## Security
For personal testing, the key can be entered on-device. Do not ship a real API key inside an APK. For a production app, put the AI call behind your own authenticated backend.
